function redirect(page) { // protocol: https, local
  	window.location.href = page;
  	window.location.replace(page);
}